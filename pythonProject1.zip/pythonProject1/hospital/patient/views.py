from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import Hospital,UserProfile,patientreg,appointment,payment,doctor_details
from django.contrib import messages
def form(request):
    return render(request,'form.html')

# Create your views here.
def admin(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        try:
            doc = doctor_details.objects.get(username=username)
            if password == doc.password:
                Hospital.objects.create(
                    username=username,
                    password=password
                )
                return redirect('admins')
            else:
                messages.error(request, 'Invalid Login Credentials')
        except doctor_details.DoesNotExist:
            messages.error(request, 'You have not registered yet')
    return render(request, 'admin.html')

def admins(request):
    return render(request, 'admin2.html')
def contact(request):
    return render(request, 'contact.html')
def doctor(request):
    return render(request, 'doctor.html')
def patient(request):
     return render(request, 'patient.html')

def patient_registration(request):
    if request.method == 'POST':
        # Handle form submission
        name = request.POST.get('name')
        age = request.POST.get('age')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        address = request.POST.get('address')
        other_health_concerns = request.POST.get('OtherHealthConcerns')

        # Create a new Patient instance and save it to the database
        patient = patientreg(
            name=name,
            age=age,
            email=email,
            phone=phone,
            address=address,
            OtherHealthConcerns=other_health_concerns
        )
        patient.save()

        # Redirect to a success page or display a success message
        # You can customize this based on your project requirements
        return HttpResponse('successfully registered') # Replace 'success_page' with your desired URL

    return render(request, 'patient_registration.html')

def payment(request):
    # Replace with your desired URL
    return render(request, 'payment.html')
def treatment_details(request):
    return render(request, 'treatment_details.html')
def treatment_appointment(request):
    if request.method == 'POST':
        # Extract form data
        name = request.POST.get('name')
        condition = request.POST.get('condition')
        treatment = request.POST.get('treatment')
        date = request.POST.get('date')
        time = request.POST.get('time')
        notes = request.POST.get('notes')

        # Create a new appointment instance
        appointment.objects.create(
            name=name,
            condition=condition,
            treatment=treatment,
            date=date,
            time=time,
            notes=notes
        )
        # Redirect to a success page or display a success message
        return redirect('payment')  # Replace with your desired URL
    return render(request, 'treatment_appointment.html')

def reg(request):
    if request.method == 'POST':
        Doctor_name = request.POST['FACNAM']
        Doctor_id = request.POST['FACID']
        password = request.POST['staffpassword']
        confrim_repassword = request.POST['confpassword']

        if password != confrim_repassword:
            messages.error(request, 'Passwords doesnt match')
        else:
            doctor_details.objects.create(
                username=Doctor_name,
                Doctor_id=Doctor_id,
                password=password
            )
            return redirect('admin')
    return render(request,'reg.html')

def doc_pat(request):
    pat=patientreg.objects.all()
    return render(request,'doc_pat.html',{'pat':pat})

def doc_app(request):
    app=appointment.objects.all()
    return render(request, 'doc_app.html', {'app': app})
