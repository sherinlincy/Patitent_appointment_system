from django.db import models


class Hospital(models.Model):
    username = models.CharField(max_length=20)
    password = models.CharField(max_length=15)


class patientreg(models.Model):
    name = models.CharField(max_length=20)
    age = models.IntegerField(max_length=2)
    email = models.CharField(max_length=20)
    phone = models.BigIntegerField(max_length=10)
    address = models.CharField(max_length=30)
    OtherHealthConcerns = models.CharField(max_length=150)

class appointment(models.Model):
    name = models.CharField(max_length=20)
    condition = models.CharField(max_length=30)
    treatment = models.CharField(max_length=30)
    date = models.DateField(max_length=30)
    time = models.TimeField(max_length=30)
    notes = models.CharField(max_length=150)

class payment(models.Model):
    full_name = models.CharField(max_length=100)
    email = models.EmailField()
    date_of_birth = models.DateField()
    gender = models.CharField(max_length=10, choices=[('Male', 'Male'), ('Female', 'Female')])
    payment_method = models.CharField(max_length=20, choices=[('Credit Card', 'Credit Card'), ('Paypal', 'Paypal')])
    card_number = models.CharField(max_length=16)
    card_cvc = models.CharField(max_length=4)


class UserProfile(models.Model):
    username = models.CharField(max_length=150, unique=True)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=128)  # Usually, you'd store a hashed password
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)
    date_of_birth = models.DateField()

class doctor_details(models.Model):
    username = models.CharField(max_length=10)
    Doctor_id = models.CharField(max_length=10)
    password = models.CharField(max_length=10)