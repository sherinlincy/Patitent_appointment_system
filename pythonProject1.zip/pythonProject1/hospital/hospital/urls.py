
from django.contrib import admin
from django.urls import path
from patient import views


urlpatterns = [
    path('adminproject/', admin.site.urls),
    path('', views.form, name='form'),
    path('admin/', views.admin, name='admin'),
    path('admin2/', views.admins, name='admins'),
    path('contact/', views.contact, name='contact'),
    path('doctor/', views.doctor, name='doctor'),
    path('patient/', views.patient, name='patient'),
    path('patient_registration/', views.patient_registration, name='patient_registration'),
    path('payment/', views.payment, name='payment'),
    path('treatment_appointment/', views.treatment_appointment, name='treatment_appointment'),
    path('treatment_details/', views.treatment_details, name='treatment_details'),
    path('reg/', views.reg,name='reg'),
    path('doc_pat',views.doc_pat,name='doc_pat'),
    path('doc_app',views.doc_app,name='doc_app')
]
